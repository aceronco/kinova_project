
from concurrent.futures import Future
from functools import partial
from deprecated import deprecated
from enum import Enum
from ... import  *
from ...internal.NotificationHandler import _NotificationCallback
from ...internal import BitMaskTools
from ..messages import EditingContext_pb2 as EditingContextPb  # NOQA
from ..messages import Common_pb2 as CommonPb  # NOQA



class EditingContextFunctionUid(Enum):
    uidSetEditingContext = 0x2d0001
    uidUnsetEditingContext = 0x2d0002



class EditingContextClient():
    
    serviceVersion = 1
    serviceId = 45

    

    def __init__(self, router: RouterClient, namespace: str = None):
        """Constructs a EditingContextClient with an initialized RouterClient and an optional namespace.
        """
        if namespace != None and not router._transport._isNamespaceSupported():
            raise ValueError("Cannot use namespace with this router's transport.")
        
        self.router = router
        self.namespace = namespace

    def IsAlive(self, timeoutMs: int = 1000) -> bool:
        """Returns True if the Service Server is detected online before timeoutMs is expired, False otherwise.
        """
        return self.router._isAlive(self.serviceId, self.namespace, timeoutMs)


    def SetEditingContext(self, context: EditingContextPb.Context, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Add the editing context to the editing context stack
        """
        reqPayload = context.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, EditingContextFunctionUid.uidSetEditingContext, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





    def UnsetEditingContext(self, contextsessionidentifier: EditingContextPb.ContextSessionIdentifier, deviceId: int = 0, options = RouterClientSendOptions()) :
        """
        Remove the editing context from the editing context stack
        """
        reqPayload = contextsessionidentifier.SerializeToString()


        future = self.router._send(reqPayload, self.serviceVersion, EditingContextFunctionUid.uidUnsetEditingContext, deviceId, self.namespace, options)

        result = future.result(options.getTimeoutInSecond())





